<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <span><i class="fas fa-arrow-left mr-3"></i>Aktivitas</span>
                        </a>
                    </h4>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <button class="btn btn-primary" wire:click="tambahKriteria">Tambah Aktivitas</button>
                    <hr>
                    <table class="table table-bordered table-head-bg-info table-bordered-bd-info">
                        <thead>
                            <tr>
                                <th scope="col">Aktivitas</th>
                                <th scope="col">Kode</th>
                                <th scope="col">Kegiatan Pendahulu</th>
                                <th scope="col">Durasi</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->nama); ?></td>
                                <td><?php echo e($data->kode); ?></td>
                                <td><?php echo e($data->pendahulu); ?></td>
                                <td><?php echo e($data->durasi); ?></td>
                                <td><button class="btn btn-primary" wire:click="showModalEdit('<?php echo e($data->id); ?>')">Edit</button>
                                    <button class="btn btn-danger" wire:click="delete('<?php echo e($data->id); ?>')">Hapus</button></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <button class="btn btn-primary pull-right" wire:click = "prosesdata">Proses Data</button>
                    <button class="btn btn-danger pull-right" wire:click = "resetProses" style="margin-right: 1%">Reset Data</button>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h3>Critical Path</h3>
                    <hr>
                    <?php $__currentLoopData = $hasil_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge badge-pill badge-success"><?php echo e($hasil->cpm->nama); ?>(<?php echo e($hasil->cpm->kode); ?>)</span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <h3>Nilai Keluaran</h3>
                    <hr>
                    <table class="table table-bordered table-head-bg-info table-bordered-bd-info">
                        <thead>
                            <tr>
                                <th scope="col">Aktivitas</th>
                                <th scope="col">Kode</th>
                                <th scope="col">Pendahulu</th>
                                <th scope="col">Penerus</th>
                                <th scope="col">Durasi</th>
                                <th scope="col">Early Start</th>
                                <th scope="col">Late Start</th>
                                <th scope="col">Early Finish</th>
                                <th scope="col">Late Finish</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $proses_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $proses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($proses->cpm->nama); ?></td>
                                    <td><?php echo e($proses->cpm->kode); ?></td>
                                    <?php if($proses->cpm->pendahulu == null): ?>
                                        <td>Mulai</td>
                                    <?php else: ?>
                                    <td><?php echo e($proses->cpm->pendahulu); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($proses->penerus); ?></td>
                                    <td><?php echo e($proses->cpm->durasi); ?></td>
                                    <td><?php echo e($proses->early_start); ?></td>
                                    <td><?php echo e($proses->late_start); ?></td>
                                    <td><?php echo e($proses->early_finish); ?></td>
                                    <td><?php echo e($proses->late_finish); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div id="modal-tambah" wire:ignore.self class="modal fade" tabindex="-1" role="dialog"
        aria-labelledby="my-modal-title" aria-hidden="true" class="justify-content-center">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="my-modal-title">Tambah Kriteria</h4>
                </div>
                <div class="modal-body">
                    <div
                        class="form-group <?php echo e($errors->has('namaKegiatan') ? 'has-error has-feedback' : ''); ?>">
                        <label for="namaKegiatan" class="placeholder"><b>Kegiatan</b></label>

                        <input id="namaKegiatan" name="namaKegiatan" wire:model="namaKegiatan" type="text"
                            class="form-control">
                        <small id="helpId<?php echo e('namaKegiatan'); ?>"
                            class="text-danger"><?php echo e($errors->has('namaKegiatan') ? $errors->first('namaKegiatan') : ''); ?></small>
                    </div>
                    <div
                        class="form-group <?php echo e($errors->has('kode') ? 'has-error has-feedback' : ''); ?>">
                        <label for="kode" class="placeholder"><b>Kode</b></label>

                        <input id="kode" name="kode" wire:model="kode" type="text"
                            class="form-control">
                        <small id="helpId<?php echo e('kode'); ?>"
                            class="text-danger"><?php echo e($errors->has('kode') ? $errors->first('kode') : ''); ?></small>
                    </div>
                    <div
                        class="form-group <?php echo e($errors->has('kegiatanPendahulu') ? 'has-error has-feedback' : ''); ?>">
                        <label for="kegiatanPendahulu" class="placeholder"><b>Kegiatan Pendahulu (Kode)</b></label>

                        <input id="kegiatanPendahulu" name="kegiatanPendahulu" wire:model="kegiatanPendahulu" type="text"
                            class="form-control">
                        <small id="helpId<?php echo e('kegiatanPendahulu'); ?>">Dipisahkan dengan koma tanpa spasi</small>
                        <small id="helpId<?php echo e('kegiatanPendahulu'); ?>"
                            class="text-danger"><?php echo e($errors->has('kegiatanPendahulu') ? $errors->first('kegiatanPendahulu') : ''); ?></small>
                    </div>
                    <div
                        class="form-group <?php echo e($errors->has('durasi') ? 'has-error has-feedback' : ''); ?>">
                        <label for="durasi" class="placeholder"><b>Durasi</b></label>

                        <input id="durasi" name="durasi" wire:model="durasi" type="text"
                            class="form-control">
                        <small id="helpId<?php echo e('durasi'); ?>"
                            class="text-danger"><?php echo e($errors->has('durasi') ? $errors->first('durasi') : ''); ?></small>
                    </div>
                </div>
                <div class="modal-footer justify-content-center">
                    <button class="btn btn-primary" wire:click="tambah">Tambah</button>
                </div>
            </div>
        </div>
    </div>

    <?php if($isEdit): ?>
    <div id="modal-edit" wire:ignore.self class="modal fade" tabindex="-1" role="dialog"
        aria-labelledby="my-modal-title" aria-hidden="true" class="justify-content-center">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="my-modal-title">Edit Kriteria</h4>
                </div>
                <div class="modal-body">
                    <div
                        class="form-group <?php echo e($errors->has('namaKegiatan') ? 'has-error has-feedback' : ''); ?>">
                        <label for="namaKegiatan" class="placeholder"><b>Kegiatan</b></label>

                        <input id="namaKegiatan" name="namaKegiatan" wire:model="namaKegiatan" type="text"
                            class="form-control">
                        <small id="helpId<?php echo e('namaKegiatan'); ?>"
                            class="text-danger"><?php echo e($errors->has('namaKegiatan') ? $errors->first('namaKegiatan') : ''); ?></small>
                    </div>
                    <div
                        class="form-group <?php echo e($errors->has('kode') ? 'has-error has-feedback' : ''); ?>">
                        <label for="kode" class="placeholder"><b>Kode</b></label>

                        <input id="kode" name="kode" wire:model="kode" type="text"
                            class="form-control">
                        <small id="helpId<?php echo e('kode'); ?>"
                            class="text-danger"><?php echo e($errors->has('kode') ? $errors->first('kode') : ''); ?></small>
                    </div>
                    <div
                        class="form-group <?php echo e($errors->has('kegiatanPendahulu') ? 'has-error has-feedback' : ''); ?>">
                        <label for="kegiatanPendahulu" class="placeholder"><b>Kegiatan Pendahulu (Kode)</b></label>

                        <input id="kegiatanPendahulu" name="kegiatanPendahulu" wire:model="kegiatanPendahulu" type="text"
                            class="form-control">
                        <small id="helpId<?php echo e('kegiatanPendahulu'); ?>">Dipisahkan dengan koma tanpa spasi</small>
                        <small id="helpId<?php echo e('kegiatanPendahulu'); ?>"
                            class="text-danger"><?php echo e($errors->has('kegiatanPendahulu') ? $errors->first('kegiatanPendahulu') : ''); ?></small>
                    </div>
                    <div
                        class="form-group <?php echo e($errors->has('durasi') ? 'has-error has-feedback' : ''); ?>">
                        <label for="durasi" class="placeholder"><b>Durasi</b></label>

                        <input id="durasi" name="durasi" wire:model="durasi" type="text"
                            class="form-control">
                        <small id="helpId<?php echo e('durasi'); ?>"
                            class="text-danger"><?php echo e($errors->has('durasi') ? $errors->first('durasi') : ''); ?></small>
                    </div>
                </div>
                <div class="modal-footer justify-content-center">
                    <button class="btn btn-primary" wire:click="edit">Simpan</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>


    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
    <script>
        document.addEventListener('livewire:load', function (e) {
            e.preventDefault()

            window.livewire.on('showModalTambah', (data) => {
                // console.log(data)
                $('#modal-tambah').modal('show')
            });
            window.livewire.on('showModalEdit', (data) => {
                // console.log(data)
                $('#modal-edit').modal('show')
            });
            window.livewire.on('hideModal', (data) => {
                $('#modal-tambah').modal('hide')
                $('#modal-edit').modal('hide')
            });

        })

    </script>
</div><?php /**PATH C:\xampp\htdocs\cpm_pert\resources\views/livewire/index.blade.php ENDPATH**/ ?>